﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;


namespace AutoCalib
{
    public partial class FormModbusSetting : Form
    {
        public string serialPort;
        public int baudRate;
        public int dataBits;
        public Parity parity;
        public StopBits stopBits;
        public Handshake handshake;
        public Byte devAddr;
        public int refreshTime;
        public string mbType;
        public FormModbusSetting()
        {
            InitializeComponent();
        }

        private void FormModbusSetting_Load(object sender, EventArgs e)
        {
            FillRTUDropDownLists();
            comboBoxBaudRate.SelectedIndex = 4;
            comboBoxStopBits.SelectedIndex = 0;
            comboBoxParity.SelectedIndex = 0;
            comboBoxDataBits.SelectedIndex = 1;
            comboBoxMbType.SelectedIndex = 0;
            numericUpDownDevAddr.Maximum = 255;
            numericUpDownDevAddr.Minimum = 1;
            numericUpDownDevAddr.Value = 170;
            btnOk.DialogResult = DialogResult.OK;
            btnCancel.DialogResult = DialogResult.Cancel;  
        }

        private void FillRTUDropDownLists()
        {
            comboBoxSerialPorts.Items.Clear();
            foreach (var port in SerialPort.GetPortNames())
            {
                comboBoxSerialPorts.Items.Add(port);
            }
            if (comboBoxSerialPorts.Items.Count > 0)
                comboBoxSerialPorts.SelectedIndex = 0;
            comboBoxParity.Items.Clear();
            comboBoxParity.Items.Add(Parity.None.ToString());
            comboBoxParity.Items.Add(Parity.Odd.ToString());
            comboBoxParity.Items.Add(Parity.Even.ToString());
            comboBoxParity.Items.Add(Parity.Mark.ToString());
            comboBoxParity.Items.Add(Parity.Space.ToString());

            comboBoxBaudRate.Items.AddRange(new object[] {
            "128000",
            "115200",
            "57600",
            "38400",
            "19200",
            "14400",
            "9600",
            "7200",
            "4800",
            "2400",
            "1800",
            "1200",
            "600",
            "300",
            "150"});

            comboBoxStopBits.Items.AddRange(new object[] {
            //"None",
            "1 Bit",
            "2 Bits",
            "1.5 Bits"});

            comboBoxDataBits.Items.AddRange(new object[] {
            "7 Bits",
            "8 Bits"});

            comboBoxMbType.Items.AddRange(new object[] {
                "Ascii",
                "RTU" });
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            serialPort = comboBoxSerialPorts.Text;
            baudRate = Int16.Parse(comboBoxBaudRate.Text);
            dataBits = comboBoxDataBits.SelectedIndex + 7;
            stopBits = (StopBits)(comboBoxStopBits.SelectedIndex+1);
            parity = (Parity)comboBoxParity.SelectedIndex;
            devAddr = Byte.Parse(numericUpDownDevAddr.Text);
            refreshTime = Int16.Parse(numericUpDownRefresTime.Text);
            mbType = comboBoxMbType.Text;

            Console.WriteLine("SerialPort:" + serialPort);
            Console.WriteLine("baudRate:" + baudRate);
            Console.WriteLine("dataBits:" + dataBits);
            Console.WriteLine("stopBits:" + stopBits);
            Console.WriteLine("parity:" + parity);
            Console.WriteLine("devAddress:" + devAddr);
            Console.WriteLine("refreshTime:" + refreshTime);
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            FillRTUDropDownLists();
        }
    }
}
