﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;



namespace AutoCalib
{
    public partial class FormSettingPID : Form
    {
        public string serialPort;
        public double[] setPoints;
        public double kp,ki,kd;
        public int timer;

        public FormSettingPID()
        {
            InitializeComponent();
            foreach (Control control in groupBoxUserSetting.Controls)
            {
                if (control.Name.Contains("numberBoxSet"))
                {
                    NumberBox box = control as NumberBox;
                    box.setBounds(0, 1000);
                }
                Console.WriteLine(control.Name);
            }
            foreach (Control control in groupBoxPID.Controls)
            {
                if (control.Name.Contains("numberBox"))
                {
                    NumberBox box = control as NumberBox;
                    box.setBounds(0, 10);
                }
                Console.WriteLine(control.Name);
            }
        }

        private void FormSettingPID_Load(object sender, EventArgs e)
        {
            //numberBoxSet1
            setPoints = new double[10];
            updateComboBoxSerial();
            numberBoxKp.text = "0";
            numberBoxKi.text = "0";
            numberBoxKd.text = "0";
            btnOk.DialogResult = DialogResult.OK;
            btnCancel.DialogResult = DialogResult.Cancel;   
        }

        private void updateComboBoxSerial()
        {
            comboBoxSerialPorts.Items.Clear();
            foreach ( var port in SerialPort.GetPortNames())
            {
                comboBoxSerialPorts.Items.Add(port);
            }
            comboBoxSerialPorts.SelectedIndex = 0;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            serialPort = comboBoxSerialPorts.SelectedItem.ToString();

            foreach (Control control in groupBoxUserSetting.Controls)
            {
                string controlName = control.Name;
                Console.WriteLine(control.Name);
                if (controlName.Contains("numberBoxSet"))
                {
                    NumberBox box = control as NumberBox;
                    string idx_string = controlName.Remove(0, 12);

                    int idx = Int16.Parse(idx_string)-1;
                    setPoints[idx] = box.doubleValue;
                }
            }

            timer = Int16.Parse(numericUpDownTimer.Value.ToString());

            kp = numberBoxKp.doubleValue;
            ki = numberBoxKi.doubleValue;
            kd = numberBoxKd.doubleValue;

            Console.WriteLine("setpoints:" + setPoints[9]);
            Console.WriteLine("kp:" + kp);
            Console.WriteLine("ki:" + ki);
            Console.WriteLine("kd:" + kd);
            Console.WriteLine("timer:" ,timer);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }

        private void btnRefreshSerial_Click(object sender, EventArgs e)
        {
            updateComboBoxSerial();
        }
    }
}
