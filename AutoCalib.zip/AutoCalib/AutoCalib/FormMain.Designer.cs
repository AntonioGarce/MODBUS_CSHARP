﻿namespace AutoCalib
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.btnConnRef = new System.Windows.Forms.Button();
            this.btnConnPump = new System.Windows.Forms.Button();
            this.btnConnGeobus = new System.Windows.Forms.Button();
            this.btnStartCalib = new System.Windows.Forms.Button();
            this.btnEndCalib = new System.Windows.Forms.Button();
            this.btnRefPressure = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.chartPressure = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.listBoxRunningStatus = new System.Windows.Forms.ListBox();
            this.buttonClear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chartPressure)).BeginInit();
            this.SuspendLayout();
            // 
            // btnConnRef
            // 
            this.btnConnRef.Location = new System.Drawing.Point(46, 31);
            this.btnConnRef.Name = "btnConnRef";
            this.btnConnRef.Size = new System.Drawing.Size(128, 31);
            this.btnConnRef.TabIndex = 0;
            this.btnConnRef.Text = "ConnectReference";
            this.btnConnRef.UseVisualStyleBackColor = true;
            this.btnConnRef.Click += new System.EventHandler(this.btnConnRef_Click);
            // 
            // btnConnPump
            // 
            this.btnConnPump.Location = new System.Drawing.Point(46, 74);
            this.btnConnPump.Name = "btnConnPump";
            this.btnConnPump.Size = new System.Drawing.Size(128, 31);
            this.btnConnPump.TabIndex = 0;
            this.btnConnPump.Text = "ConnectPump";
            this.btnConnPump.UseVisualStyleBackColor = true;
            this.btnConnPump.Click += new System.EventHandler(this.btnConnPump_Click);
            // 
            // btnConnGeobus
            // 
            this.btnConnGeobus.Location = new System.Drawing.Point(46, 115);
            this.btnConnGeobus.Name = "btnConnGeobus";
            this.btnConnGeobus.Size = new System.Drawing.Size(128, 31);
            this.btnConnGeobus.TabIndex = 0;
            this.btnConnGeobus.Text = "ConnectGeobus";
            this.btnConnGeobus.UseVisualStyleBackColor = true;
            // 
            // btnStartCalib
            // 
            this.btnStartCalib.Location = new System.Drawing.Point(46, 175);
            this.btnStartCalib.Name = "btnStartCalib";
            this.btnStartCalib.Size = new System.Drawing.Size(128, 42);
            this.btnStartCalib.TabIndex = 0;
            this.btnStartCalib.Text = "StartCalibration";
            this.btnStartCalib.UseVisualStyleBackColor = true;
            this.btnStartCalib.Click += new System.EventHandler(this.btnStartCalib_Click);
            // 
            // btnEndCalib
            // 
            this.btnEndCalib.Enabled = false;
            this.btnEndCalib.Location = new System.Drawing.Point(46, 223);
            this.btnEndCalib.Name = "btnEndCalib";
            this.btnEndCalib.Size = new System.Drawing.Size(128, 42);
            this.btnEndCalib.TabIndex = 0;
            this.btnEndCalib.Text = "End Calibration";
            this.btnEndCalib.UseVisualStyleBackColor = true;
            this.btnEndCalib.Click += new System.EventHandler(this.btnEndCalib_Click);
            // 
            // btnRefPressure
            // 
            this.btnRefPressure.Location = new System.Drawing.Point(193, 31);
            this.btnRefPressure.Name = "btnRefPressure";
            this.btnRefPressure.Size = new System.Drawing.Size(139, 31);
            this.btnRefPressure.TabIndex = 0;
            this.btnRefPressure.Text = "RefPressure value here";
            this.btnRefPressure.UseVisualStyleBackColor = true;
            this.btnRefPressure.Click += new System.EventHandler(this.btnRefPressure_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(193, 74);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(139, 31);
            this.button7.TabIndex = 0;
            this.button7.Text = "Connected/Disconnected";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(193, 115);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(139, 31);
            this.button8.TabIndex = 0;
            this.button8.Text = "Connected/Disconnected";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // chartPressure
            // 
            chartArea1.Name = "ChartArea1";
            this.chartPressure.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartPressure.Legends.Add(legend1);
            this.chartPressure.Location = new System.Drawing.Point(353, 33);
            this.chartPressure.Name = "chartPressure";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Legend = "Legend1";
            series1.Name = "SetPoints";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "ReferencePressure";
            this.chartPressure.Series.Add(series1);
            this.chartPressure.Series.Add(series2);
            this.chartPressure.Size = new System.Drawing.Size(435, 342);
            this.chartPressure.TabIndex = 1;
            this.chartPressure.Text = "Reference Pressure";
            // 
            // listBoxRunningStatus
            // 
            this.listBoxRunningStatus.FormattingEnabled = true;
            this.listBoxRunningStatus.Location = new System.Drawing.Point(75, 391);
            this.listBoxRunningStatus.Name = "listBoxRunningStatus";
            this.listBoxRunningStatus.Size = new System.Drawing.Size(616, 30);
            this.listBoxRunningStatus.TabIndex = 3;
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(696, 392);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(64, 28);
            this.buttonClear.TabIndex = 4;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.listBoxRunningStatus);
            this.Controls.Add(this.chartPressure);
            this.Controls.Add(this.btnEndCalib);
            this.Controls.Add(this.btnStartCalib);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.btnConnGeobus);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.btnConnPump);
            this.Controls.Add(this.btnRefPressure);
            this.Controls.Add(this.btnConnRef);
            this.Name = "FormMain";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chartPressure)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnConnRef;
        private System.Windows.Forms.Button btnConnPump;
        private System.Windows.Forms.Button btnConnGeobus;
        private System.Windows.Forms.Button btnStartCalib;
        private System.Windows.Forms.Button btnEndCalib;
        private System.Windows.Forms.Button btnRefPressure;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPressure;
        private System.Windows.Forms.ListBox listBoxRunningStatus;
        private System.Windows.Forms.Button buttonClear;
    }
}

