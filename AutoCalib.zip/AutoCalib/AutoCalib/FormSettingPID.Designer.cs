﻿namespace AutoCalib
{
    partial class FormSettingPID
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxConnection = new System.Windows.Forms.GroupBox();
            this.btnRefreshSerial = new System.Windows.Forms.Button();
            this.comboBoxSerialPorts = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxUserSetting = new System.Windows.Forms.GroupBox();
            this.numericUpDownTimer = new System.Windows.Forms.NumericUpDown();
            this.numberBoxSet8 = new AutoCalib.NumberBox();
            this.numberBoxSet7 = new AutoCalib.NumberBox();
            this.numberBoxSet4 = new AutoCalib.NumberBox();
            this.numberBoxSet10 = new AutoCalib.NumberBox();
            this.numberBoxSet6 = new AutoCalib.NumberBox();
            this.numberBoxSet9 = new AutoCalib.NumberBox();
            this.numberBoxSet3 = new AutoCalib.NumberBox();
            this.numberBoxSet5 = new AutoCalib.NumberBox();
            this.numberBoxSet2 = new AutoCalib.NumberBox();
            this.numberBoxSet1 = new AutoCalib.NumberBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxPID = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numberBoxKi = new AutoCalib.NumberBox();
            this.numberBoxKd = new AutoCalib.NumberBox();
            this.numberBoxKp = new AutoCalib.NumberBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.groupBoxConnection.SuspendLayout();
            this.groupBoxUserSetting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTimer)).BeginInit();
            this.groupBoxPID.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxConnection
            // 
            this.groupBoxConnection.Controls.Add(this.btnRefreshSerial);
            this.groupBoxConnection.Controls.Add(this.comboBoxSerialPorts);
            this.groupBoxConnection.Controls.Add(this.label1);
            this.groupBoxConnection.Location = new System.Drawing.Point(24, 25);
            this.groupBoxConnection.Name = "groupBoxConnection";
            this.groupBoxConnection.Size = new System.Drawing.Size(395, 64);
            this.groupBoxConnection.TabIndex = 0;
            this.groupBoxConnection.TabStop = false;
            this.groupBoxConnection.Text = "Connection";
            // 
            // btnRefreshSerial
            // 
            this.btnRefreshSerial.Location = new System.Drawing.Point(278, 27);
            this.btnRefreshSerial.Name = "btnRefreshSerial";
            this.btnRefreshSerial.Size = new System.Drawing.Size(79, 20);
            this.btnRefreshSerial.TabIndex = 2;
            this.btnRefreshSerial.Text = "Refresh";
            this.btnRefreshSerial.UseVisualStyleBackColor = true;
            this.btnRefreshSerial.Click += new System.EventHandler(this.btnRefreshSerial_Click);
            // 
            // comboBoxSerialPorts
            // 
            this.comboBoxSerialPorts.FormattingEnabled = true;
            this.comboBoxSerialPorts.Location = new System.Drawing.Point(98, 27);
            this.comboBoxSerialPorts.Name = "comboBoxSerialPorts";
            this.comboBoxSerialPorts.Size = new System.Drawing.Size(151, 21);
            this.comboBoxSerialPorts.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Serial Port:";
            // 
            // groupBoxUserSetting
            // 
            this.groupBoxUserSetting.Controls.Add(this.numericUpDownTimer);
            this.groupBoxUserSetting.Controls.Add(this.numberBoxSet8);
            this.groupBoxUserSetting.Controls.Add(this.numberBoxSet7);
            this.groupBoxUserSetting.Controls.Add(this.numberBoxSet4);
            this.groupBoxUserSetting.Controls.Add(this.numberBoxSet10);
            this.groupBoxUserSetting.Controls.Add(this.numberBoxSet6);
            this.groupBoxUserSetting.Controls.Add(this.numberBoxSet9);
            this.groupBoxUserSetting.Controls.Add(this.numberBoxSet3);
            this.groupBoxUserSetting.Controls.Add(this.numberBoxSet5);
            this.groupBoxUserSetting.Controls.Add(this.numberBoxSet2);
            this.groupBoxUserSetting.Controls.Add(this.numberBoxSet1);
            this.groupBoxUserSetting.Controls.Add(this.label4);
            this.groupBoxUserSetting.Controls.Add(this.label3);
            this.groupBoxUserSetting.Controls.Add(this.label2);
            this.groupBoxUserSetting.Location = new System.Drawing.Point(23, 102);
            this.groupBoxUserSetting.Name = "groupBoxUserSetting";
            this.groupBoxUserSetting.Size = new System.Drawing.Size(490, 154);
            this.groupBoxUserSetting.TabIndex = 1;
            this.groupBoxUserSetting.TabStop = false;
            this.groupBoxUserSetting.Text = "User Setting";
            // 
            // numericUpDownTimer
            // 
            this.numericUpDownTimer.Location = new System.Drawing.Point(99, 113);
            this.numericUpDownTimer.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownTimer.Name = "numericUpDownTimer";
            this.numericUpDownTimer.Size = new System.Drawing.Size(84, 20);
            this.numericUpDownTimer.TabIndex = 4;
            this.numericUpDownTimer.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numberBoxSet8
            // 
            this.numberBoxSet8.Location = new System.Drawing.Point(393, 54);
            this.numberBoxSet8.Name = "numberBoxSet8";
            this.numberBoxSet8.Size = new System.Drawing.Size(91, 26);
            this.numberBoxSet8.TabIndex = 3;
            this.numberBoxSet8.text = "";
            // 
            // numberBoxSet7
            // 
            this.numberBoxSet7.Location = new System.Drawing.Point(300, 54);
            this.numberBoxSet7.Name = "numberBoxSet7";
            this.numberBoxSet7.Size = new System.Drawing.Size(97, 26);
            this.numberBoxSet7.TabIndex = 3;
            this.numberBoxSet7.text = "";
            // 
            // numberBoxSet4
            // 
            this.numberBoxSet4.Location = new System.Drawing.Point(393, 31);
            this.numberBoxSet4.Name = "numberBoxSet4";
            this.numberBoxSet4.Size = new System.Drawing.Size(91, 26);
            this.numberBoxSet4.TabIndex = 3;
            this.numberBoxSet4.text = "";
            // 
            // numberBoxSet10
            // 
            this.numberBoxSet10.Location = new System.Drawing.Point(203, 77);
            this.numberBoxSet10.Name = "numberBoxSet10";
            this.numberBoxSet10.Size = new System.Drawing.Size(97, 26);
            this.numberBoxSet10.TabIndex = 3;
            this.numberBoxSet10.text = "";
            // 
            // numberBoxSet6
            // 
            this.numberBoxSet6.Location = new System.Drawing.Point(203, 54);
            this.numberBoxSet6.Name = "numberBoxSet6";
            this.numberBoxSet6.Size = new System.Drawing.Size(97, 26);
            this.numberBoxSet6.TabIndex = 3;
            this.numberBoxSet6.text = "";
            // 
            // numberBoxSet9
            // 
            this.numberBoxSet9.Location = new System.Drawing.Point(100, 77);
            this.numberBoxSet9.Name = "numberBoxSet9";
            this.numberBoxSet9.Size = new System.Drawing.Size(97, 26);
            this.numberBoxSet9.TabIndex = 3;
            this.numberBoxSet9.text = "";
            // 
            // numberBoxSet3
            // 
            this.numberBoxSet3.Location = new System.Drawing.Point(300, 31);
            this.numberBoxSet3.Name = "numberBoxSet3";
            this.numberBoxSet3.Size = new System.Drawing.Size(97, 26);
            this.numberBoxSet3.TabIndex = 3;
            this.numberBoxSet3.text = "";
            // 
            // numberBoxSet5
            // 
            this.numberBoxSet5.Location = new System.Drawing.Point(100, 54);
            this.numberBoxSet5.Name = "numberBoxSet5";
            this.numberBoxSet5.Size = new System.Drawing.Size(97, 26);
            this.numberBoxSet5.TabIndex = 3;
            this.numberBoxSet5.text = "";
            // 
            // numberBoxSet2
            // 
            this.numberBoxSet2.Location = new System.Drawing.Point(203, 31);
            this.numberBoxSet2.Name = "numberBoxSet2";
            this.numberBoxSet2.Size = new System.Drawing.Size(97, 26);
            this.numberBoxSet2.TabIndex = 3;
            this.numberBoxSet2.text = "";
            // 
            // numberBoxSet1
            // 
            this.numberBoxSet1.Location = new System.Drawing.Point(100, 31);
            this.numberBoxSet1.Name = "numberBoxSet1";
            this.numberBoxSet1.Size = new System.Drawing.Size(97, 26);
            this.numberBoxSet1.TabIndex = 3;
            this.numberBoxSet1.text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(184, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "mins";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Timer:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Set Points:";
            // 
            // groupBoxPID
            // 
            this.groupBoxPID.Controls.Add(this.label7);
            this.groupBoxPID.Controls.Add(this.label6);
            this.groupBoxPID.Controls.Add(this.label5);
            this.groupBoxPID.Controls.Add(this.numberBoxKi);
            this.groupBoxPID.Controls.Add(this.numberBoxKd);
            this.groupBoxPID.Controls.Add(this.numberBoxKp);
            this.groupBoxPID.Location = new System.Drawing.Point(23, 273);
            this.groupBoxPID.Name = "groupBoxPID";
            this.groupBoxPID.Size = new System.Drawing.Size(488, 61);
            this.groupBoxPID.TabIndex = 2;
            this.groupBoxPID.TabStop = false;
            this.groupBoxPID.Text = "PID Parameters";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(346, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Kd:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(199, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Ki:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Kp:";
            // 
            // numberBoxKi
            // 
            this.numberBoxKi.Location = new System.Drawing.Point(225, 26);
            this.numberBoxKi.Name = "numberBoxKi";
            this.numberBoxKi.Size = new System.Drawing.Size(97, 26);
            this.numberBoxKi.TabIndex = 3;
            this.numberBoxKi.text = "";
            // 
            // numberBoxKd
            // 
            this.numberBoxKd.Location = new System.Drawing.Point(379, 26);
            this.numberBoxKd.Name = "numberBoxKd";
            this.numberBoxKd.Size = new System.Drawing.Size(97, 26);
            this.numberBoxKd.TabIndex = 3;
            this.numberBoxKd.text = "";
            // 
            // numberBoxKp
            // 
            this.numberBoxKp.Location = new System.Drawing.Point(89, 26);
            this.numberBoxKp.Name = "numberBoxKp";
            this.numberBoxKp.Size = new System.Drawing.Size(97, 26);
            this.numberBoxKp.TabIndex = 3;
            this.numberBoxKp.text = "";
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(85, 349);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(144, 27);
            this.btnOk.TabIndex = 3;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(307, 349);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(144, 27);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // FormSettingPID
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 384);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.groupBoxPID);
            this.Controls.Add(this.groupBoxUserSetting);
            this.Controls.Add(this.groupBoxConnection);
            this.Name = "FormSettingPID";
            this.Text = "FormSettingPID";
            this.Load += new System.EventHandler(this.FormSettingPID_Load);
            this.groupBoxConnection.ResumeLayout(false);
            this.groupBoxConnection.PerformLayout();
            this.groupBoxUserSetting.ResumeLayout(false);
            this.groupBoxUserSetting.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTimer)).EndInit();
            this.groupBoxPID.ResumeLayout(false);
            this.groupBoxPID.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxConnection;
        private System.Windows.Forms.Button btnRefreshSerial;
        private System.Windows.Forms.ComboBox comboBoxSerialPorts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBoxUserSetting;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxPID;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private NumberBox numberBoxSet8;
        private NumberBox numberBoxSet7;
        private NumberBox numberBoxSet4;
        private NumberBox numberBoxSet10;
        private NumberBox numberBoxSet6;
        private NumberBox numberBoxSet9;
        private NumberBox numberBoxSet3;
        private NumberBox numberBoxSet5;
        private NumberBox numberBoxSet2;
        private NumberBox numberBoxSet1;
        private NumberBox numberBoxKi;
        private NumberBox numberBoxKd;
        private NumberBox numberBoxKp;
        private System.Windows.Forms.NumericUpDown numericUpDownTimer;
    }
}