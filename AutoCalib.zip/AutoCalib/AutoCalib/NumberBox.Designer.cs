﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoCalib
{
    partial class NumberBox
    {
        private double _maxValue;
        private double _minValue;
        private bool _flag;
        private string _previousValue;
        
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxNumber = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBoxNumber
            // 
            this.textBoxNumber.Location = new System.Drawing.Point(0, 0);
            this.textBoxNumber.Name = "textBoxNumber";
            this.textBoxNumber.Size = new System.Drawing.Size(85, 20);
            this.textBoxNumber.TabIndex = 0;
            // 
            // NumberBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.textBoxNumber);
            this.Name = "NumberBox";
            this.Size = new System.Drawing.Size(85, 21);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            _previousValue = textBoxNumber.Text;
            _flag = textBoxNumber.SelectedText.Length > 0;
        }

        public double doubleValue
        {
            get
            {
                if (textBoxNumber.Text == "")
                {
                    textBoxNumber.Text = "0";
                }
                return Convert.ToDouble(textBoxNumber.Text);
            }
        }

        public string text
        {
            get
            {
                return textBoxNumber.Text;
            }
            set
            {
                textBoxNumber.Text = value;
            }
        }
        private void TextBox_TextChanged(object sender, EventArgs e)
        //private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var text = textBoxNumber.Text;
            if (text.Length < 1) return;
            var cursorPosition = textBoxNumber.SelectionStart == 0 ? textBoxNumber.SelectionStart : textBoxNumber.SelectionStart - 1;
            var insertedChar = text[cursorPosition];
            if (IsInvalidInput(insertedChar, cursorPosition, text))
            {
                HandleText(text, cursorPosition);
            }
            ValidateRange(text, cursorPosition);
        }

        private bool IsInvalidInput(char insertedChar, int cursorPosition, string text)
        {
            return !char.IsDigit(insertedChar) && insertedChar != '.' && insertedChar != '-' ||
                   insertedChar == '-' && cursorPosition != 0 ||
                   text.Count(x => x == '.') > 1 ||
                   text.Count(x => x == '-') > 1;
        }

        private void HandleText(string text, int cursorPosition)
        {
            textBoxNumber.Text = _flag ? _previousValue : text.Remove(cursorPosition, 1);
            textBoxNumber.SelectionStart = cursorPosition;
            textBoxNumber.SelectionLength = 0;
        }

        private void ValidateRange(string text, int cursorPosition)
        {
            try
            {
                if (text == "." || _minValue < 0 && text == "-") return;
                var doubleValue = Convert.ToDouble(text);
                if (doubleValue > _maxValue || doubleValue < _minValue)
                {
                    HandleText(text, cursorPosition);
                }
            }
            catch (Exception)
            {
                HandleText(text, cursorPosition);
            }
        }

        public void setBounds(double minValue, double maxValue)
        {
            _minValue = minValue;
            _maxValue = maxValue;
            Console.WriteLine("minValue:" + minValue + ", maxValue:" + maxValue);
        }
        protected void SetProperties(double minValue = double.MinValue, double maxValue = double.MaxValue)
        {
            _minValue = minValue;
            _maxValue = maxValue;
        }


        private System.Windows.Forms.TextBox textBoxNumber;
    }
}
