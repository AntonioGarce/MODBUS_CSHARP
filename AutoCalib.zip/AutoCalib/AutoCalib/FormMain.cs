﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using csModbusLib;
using System.IO;
using System.IO.Ports;
using System.Globalization;

namespace AutoCalib
{
    public enum ErrorSerial
    {
        NO_ERROR = 0,
        LENGTH_ERROR,
        FRAME_ERROR,
        COMM_ERROR
    }
    public partial class FormMain : Form
    {
        private csModbusLib.ConnectionType InterfaceType = ConnectionType.NO_CONNECTION;
        private MbMaster ModMaster;
        private MbInterface modbusConnection;
        private Boolean modRefRunning = false;
        private Boolean refPressureHere = false;
        private Byte devAddrRefSensor;

        private SerialPort pidSerial = new SerialPort();
        private double kp, ki, kd;
        private double []setPoints = new double[10];
        private Boolean pumpRunning = false;
        private int Ts = 1; //control period

        private Timer mainTimer = new Timer();
        private Timer auxTimer = new Timer();

        private Int32 time = 0;

        private DateTime calibTime;

        private ushort []modData = new ushort[2];

        private Byte step;

        private Boolean firstCmd = false;

        private string fileName;

        private Boolean calibRunning = false;

        private char[] recvBuffer = new char[10];
        private double prev_err, err, sum_err;

        private double setPoint;
        private float pressure;

        private byte numErrRef, numErrPump;

        public FormMain()
        {
            InitializeComponent();

            mainTimer.Enabled = false;
            auxTimer.Enabled = false;
            mainTimer.Tick += MainTimer_Tick;
            auxTimer.Tick += AuxTimer_Tick;
            mainTimer.Interval = 1000*Ts;              //1s
            auxTimer.Interval = 1*60*1000;          //1min
            ModMaster = new MbMaster();
        }

        private void setRunningStatus(string text, Color color)
        {
            listBoxRunningStatus.Items.Add(text);
            listBoxRunningStatus.BackColor = color;
            listBoxRunningStatus.SetSelected(listBoxRunningStatus.Items.Count-1,true);
        }
        private void AuxTimer_Tick(object sender, EventArgs e)
        {
            Console.WriteLine("auxtimer");
            char[] buffer = new char[3];
            auxTimer.Stop();
            if (step<10 && setPoints[step+1] > 0)
            {
                step += 1;
                ErrorSerial errSerial = sendCommand("RU", buffer, 3);
                if (errSerial != ErrorSerial.NO_ERROR)
                {
                    errSerial = sendCommand("RU", buffer, 3);
                    if (errSerial != ErrorSerial.NO_ERROR)
                    {
                        setRunningStatus("Restarting pump is failed..", Color.Red);
                        return;
                    }
                }
                setRunningStatus("Pump is restarted.", Color.Green);
                calibRunning = true;
            }
            else
            {
                endCalibration();
            }
            
            //throw new NotImplementedException();
        }

        private void MainTimer_Tick(object sender, EventArgs e)
        {
            //read reference pressure with modbus
            
            ModMaster.Slave_ID = devAddrRefSensor;
            ErrorCodes errorCodes = ModMaster.ReadInputRegisters(24, 2, modData);
            if(errorCodes != ErrorCodes.NO_ERROR)
            {
                string errString="";
                numErrRef += 1;
                switch(errorCodes)
                {
                    case ErrorCodes.RX_TIMEOUT:
                        errString = "RX_TIMEOUT";
                        break;
                    case ErrorCodes.TX_TIMEOUT:
                        errString = "TX_TIMEOUT";
                        break;
                    case ErrorCodes.CONNECTION_CLOSED:
                        numErrRef = 3;
                        errString = "CONNECTION_CLOSED";
                        break;
                    case ErrorCodes.MESSAGE_INCOMPLETE:
                        errString = "MESSAGE_INCOMPLETE";
                        break;
                    case ErrorCodes.CONNECTION_ERROR:
                        errString = "CONNECTION_ERROR";
                        break;
                    case ErrorCodes.WRONG_IDENTIFIER:
                        errString = "WRONG_IDENTIFIER";
                        break;
                    case ErrorCodes.WRONG_CRC:
                        errString = "WRONG_CRC";
                        break;
                    case ErrorCodes.ILLEGAL_FUNCTION_CODE:
                        errString = "ILLEGAL_FUNCTION_CODE";
                        break;
                    case ErrorCodes.MODBUS_EXCEPTION:
                        errString = "MODBUS_EXCEPTION";
                        break;
                    default: 
                        break;
                }

                setRunningStatus("Modbus Error:" + errString, Color.Red);
            }
            else
            {
                byte[] bytes = new byte[4];
                bytes[0] = (byte)(modData[1] & 0xFF);
                bytes[1] = (byte)(modData[1] >> 8);
                bytes[2] = (byte)(modData[0] & 0xFF);
                bytes[3] = (byte)(modData[0] >> 8);
                pressure = BitConverter.ToSingle(bytes, 0);
            }
            setRunningStatus("Main Timer:" + pressure,Color.Green);
            setPoint = setPoints[step];
            if (calibRunning)   //calibration running state
            {
                if (numErrRef >= 3)
                {
                    //end calibration
                    endCalibration();
                    setRunningStatus("Calibration is stopped since of modbus reference seneor.",Color.Red);                    
                }
                //calculate the control variable using pid
                err = setPoint - pressure;
                ErrorSerial errSerial;
                if (err / setPoint <= 0.05)
                {
                    calibRunning = false;
                    setRunningStatus("Stop Calibration for a min.", Color.Green);
                    errSerial = sendCommand("ST", recvBuffer, 3);
                    if (errSerial != ErrorSerial.NO_ERROR)
                    {
                        if (ErrorSerial.NO_ERROR != sendCommand("ST", recvBuffer, 3))
                        {
                            setRunningStatus("Pump can't be stopped in here. Calibration is stopped.", Color.Red);
                            endCalibration();
                            return;
                        }
                    }
                    auxTimer.Start();
                    return;
                }
                sum_err += ki * err;
                if (firstCmd)
                {
                    firstCmd = false;
                    prev_err = err;
                }
                double controlVar = kp * err + kd * (err - prev_err) + sum_err;
                prev_err = err;
                //send command to the pid with serial(ascii)
                
                if (controlVar<0.10)
                {
                    controlVar = 0.10;
                }
                else if(controlVar>10.0)
                {
                    controlVar = 10.000;
                }
                string cmd = "SF"+ String.Format("{0:00.000}", controlVar);

                errSerial = sendCommand(cmd, recvBuffer, 3);
                if(errSerial != ErrorSerial.NO_ERROR)
                {
                    numErrPump += 1;
                    if(numErrPump >= 3)
                    {
                        endCalibration();
                    }
                }
                else
                {
                    numErrPump = 0;
                }
            }
            //plot pressure
            time += 1;
            chartPressure.Series["ReferencePressure"].Points.AddXY(time, pressure);
            chartPressure.Series["SetPoints"].Points.AddXY(time, setPoint);
            chartPressure.Update();
            Console.WriteLine("main timer.");
            //throw new NotImplementedException();
        }
            
        private Boolean MasterConnect()
        {
            if(ModMaster.IsConnected) 
               return true;
            //lbLastError.Text = "Connecting.."
            Update();
            return ModMaster.Connect(modbusConnection, 1);
        }

        private void btnConnRef_Click(object sender, EventArgs e)
        {
            btnConnRef.Enabled = false;
            FormModbusSetting modbusSetting = new FormModbusSetting();
            if (ModMaster.IsConnected)
            {
                ModMaster.Close();
                btnConnRef.Text = "Connect Reference";
                btnConnRef.BackColor = Color.LightGray;
                btnConnRef.Enabled = true;
                return;
            }
            else if (modbusSetting.ShowDialog() == DialogResult.OK)
            {
                if (modbusSetting.mbType == "Ascii")
                {
                    InterfaceType = csModbusLib.ConnectionType.SERIAL_ASCII;
                    MbASCII mb = new MbASCII();
                    mb.SetComParms(modbusSetting.serialPort, modbusSetting.baudRate, modbusSetting.dataBits, modbusSetting.parity, modbusSetting.stopBits, modbusSetting.handshake);
                    modbusConnection = mb;
                }
                else
                {
                    InterfaceType = csModbusLib.ConnectionType.SERIAL_RTU;
                    MbRTU mb = new MbRTU();
                    mb.SetComParms(modbusSetting.serialPort, modbusSetting.baudRate, modbusSetting.dataBits, modbusSetting.parity, modbusSetting.stopBits, modbusSetting.handshake);
                    modbusConnection = mb;
                }

                if (MasterConnect())
                {
                    devAddrRefSensor = modbusSetting.devAddr;
                    modRefRunning = true;
                    btnConnRef.Text = "STOP";
                    btnConnRef.BackColor = Color.Red;
                }

            }
            btnConnRef.Enabled = true;
        }

        private void FormMain_Load(object sender, EventArgs e)
        {

        }

        private void btnRefPressure_Click(object sender, EventArgs e)
        {
            if(refPressureHere == false)
            {
                if(modRefRunning == false)
                {
                    setRunningStatus("Please connect to the Modbus Serial port.",Color.Red);
                }
                else
                {
                    clearChart();
                    mainTimer.Start();
                    refPressureHere = true;
                    btnRefPressure.BackColor = Color.Red;                   
                }

            }
            else
            {
                mainTimer.Stop();
                refPressureHere = false;
                btnRefPressure.BackColor = Color.LightGray;
            }

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listBoxRunningStatus.Items.Clear();
            listBoxRunningStatus.BackColor = Color.LightGray;
        }

        private void btnStartCalib_Click(object sender, EventArgs e)
        {
            if(modRefRunning == false)
            {
                MessageBox.Show("You should connect to reference sensor.");
            }
            else if(pumpRunning == false)
            {
                MessageBox.Show("You should connect to pump.");
            } else if (setPoints[0] == 0)
            {
                MessageBox.Show("You should set setpoints.");
            }
            else
            {
                //send cmd to the pump to start calibration
                char[] buffer = new char[3];
                ErrorSerial errSerial = sendCommand("RU" ,buffer, 3);
                if(errSerial == ErrorSerial.NO_ERROR)
                {
                    clearChart();                
                    calibRunning = true;
                    step = 0;
                    numErrRef = 0;
                    numErrPump = 0;
                    firstCmd = true;
                    mainTimer.Start();
                    btnStartCalib.Enabled = false;
                    btnEndCalib.Enabled = true;
                    setRunningStatus("Calibration is started.", Color.Green);
                    calibTime = DateTime.Now;
                    fileName = calibTime.ToString("yyyyMMddHHmmss") + ".csv";
                    
                }              

            }

        }

        private void clearChart()
        {
            time = 0;
            chartPressure.Series["SetPoints"].Points.Clear();
            chartPressure.Series["ReferencePressure"].Points.Clear();
        }
        private void btnConnPump_Click(object sender, EventArgs e)
        {
            btnConnPump.Enabled = false;
            FormSettingPID settingPID = new FormSettingPID();
            if (pidSerial.IsOpen)
            {
                pidSerial.Close();
                btnConnPump.Text = "Connect Pump";
                btnConnPump.BackColor = Color.LightGray;
                pumpRunning = false;
                btnConnPump.Enabled = true;
            }
            else if (settingPID.ShowDialog() == DialogResult.OK)
            {               
                pidSerial.PortName = settingPID.serialPort;
                pidSerial.BaudRate = 9600;
                pidSerial.DataBits = 8;
                pidSerial.StopBits = StopBits.One;
                pidSerial.Parity = Parity.None;
                pidSerial.WriteTimeout = 100;
                pidSerial.ReadTimeout = 100;

                kp = settingPID.kp;
                ki = settingPID.ki*Ts;
                kd = settingPID.kd/Ts;

                setPoints = settingPID.setPoints;

                try
                {
                    pidSerial.Open();
                }
                catch
                {
                    MessageBox.Show("Open failed. Port may be already opened by another device.");
                    btnConnPump.Enabled = true;
                    return;
                }
                btnConnPump.Text = "Stop";
                btnConnPump.BackColor = Color.Red;
                pumpRunning = true;
                auxTimer.Interval = 60 * 1000 * settingPID.timer;
            }
            btnConnPump.Enabled = true;
        }

        private void btnEndCalib_Click(object sender, EventArgs e)
        {
            endCalibration();
        }

        private void endCalibration()
        {
            setRunningStatus("End Calibration...",Color.Green);
            ErrorSerial errSerial = sendCommand("ST", recvBuffer, 3);
            if(errSerial != ErrorSerial.NO_ERROR)
            {
                if(ErrorSerial.NO_ERROR != sendCommand("ST", recvBuffer, 3))
                {
                    setRunningStatus("Pump can't be stopped in here. Please stop it manually.",Color.Red);
                }
            }
            calibRunning = false;
            mainTimer.Stop();
            auxTimer.Stop();
            btnStartCalib.Enabled = true;
            btnEndCalib.Enabled = false;

            Array refPointsArray = chartPressure.Series["ReferencePressure"].Points.ToArray();
            string strText = "";
            for (var i = 0; i < refPointsArray.Length; i++)
            {
                Console.WriteLine("i:" + refPointsArray.GetValue(i));
                Console.WriteLine(chartPressure.Series["ReferencePressure"].Points[i].YValues[0]);
                double setVal = chartPressure.Series["SetPoints"].Points[i].YValues[0];
                double refVal = chartPressure.Series["ReferencePressure"].Points[i].YValues[0];
                strText += setVal.ToString() + "," + refVal.ToString() + "\n";
            }

            File.WriteAllText(fileName, strText);
        }

        private ErrorSerial sendCommand(string cmd, char[] recvbuffer, int recvLen)
        {
            pidSerial.Write(cmd);
            try
            {
                //string buffer = pidSerial.ReadLine();
                char[] buffer = new char[recvLen+recvLen];
                char[] tempbuf = new char[recvLen];
                int numread=0, numtempread;
                byte numTry = 3;

                pidSerial.ReadTimeout = 100;

                while (numread < recvLen)
                {
                    numtempread = pidSerial.Read(tempbuf, 0, recvLen);
                    Array.Copy(tempbuf,0,buffer,numread,numtempread);
                    numread += numtempread;
                    if (--numTry==0) break;
                }

                if (numread >= recvLen)
                {
                    if (buffer[0] == 'O' && buffer[1] == 'K' && buffer[recvLen-1] == '/') //FRAME CHECK
                    {
                        recvbuffer = new char[recvLen-3];
                        Array.Copy(buffer,2,recvbuffer,0,recvLen-3);
                        return ErrorSerial.NO_ERROR;
                    }
                    else
                    {
                        Console.WriteLine("Communication with pump is not good.");
                        setRunningStatus("not found OK in the receive.",Color.Red);
                        return ErrorSerial.FRAME_ERROR;
                    }
                }
                else
                {
                    Console.WriteLine("pidSerial receive length Error");
                    setRunningStatus("Pump device receive length error.",Color.Red);
                    return ErrorSerial.LENGTH_ERROR;
                }
            }
            catch
            {
                Console.WriteLine("Pump is not responed.Timeout Exception in PIDSerial.");
                setRunningStatus("Pump device receive length error.",Color.Red);
                return ErrorSerial.COMM_ERROR;
            }
        }
    }
}
