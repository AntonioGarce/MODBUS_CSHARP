﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoCalib
{
    public partial class NumberBox : UserControl
    {
        public NumberBox()
        {
            InitializeComponent();

            textBoxNumber.TextAlign = HorizontalAlignment.Right;
            //TextAlignment = TextAlignment.Right;
            textBoxNumber.KeyDown += TextBox_KeyDown;
            textBoxNumber.TextChanged += TextBox_TextChanged;
            _minValue = double.MinValue;
            _maxValue = double.MaxValue;

        }
    }
}
